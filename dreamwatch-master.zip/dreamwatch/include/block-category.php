<div id="block-category">
<p class="header-title">Категории товаров</p>

<ul>
<li><a id="index1"><img src="images/watch-icon.png" id="watch-images"/>Карманные</a>
 <ul class="category-section">
 <li><a href="view_cat.php?type=pocket"><strong>Все модели</strong></a></li>
 <?php
 $result = mysql_query("SELECT * FROM category WHERE type ='pocket'");
 if(mysql_num_rows($result)>0)
 {
	 do
 {
	 echo'
	 <li><a href="view_cat.php?cat='.strtolower($row["brand"]).'&type='.$row["type"].'">'.$row["brand"].'</a></li>
	 ';
	 
 }
 while ($row = mysql_fetch_array($result));
 }
 ?>
 
 </ul>
</li>

<li><a id="index2"><img src="images/type-icon.png" id="type-images"/>Наручные</a>
 <ul class="category-section">
 <li><a href="view_cat.php?type=hand"><strong>Все модели</strong></a></li>
 <?php
 $result = mysql_query("SELECT * FROM category WHERE type ='hand'");
 if(mysql_num_rows($result)>0)
 {
	 do
 {
	 echo'
	 <li><a href="view_cat.php?cat='.strtolower($row["brand"]).'&type='.$row["type"].'">'.$row["brand"].'</a></li>
	 ';
	 
 }
 while ($row = mysql_fetch_array($result));
 }
 ?>
 </ul>
</li>

<li><a id="index3"><img src="images/proizv-icon.png" id="proizv-images"/>Настенные</a>
 <ul class="category-section">
 <li><a href="view_cat.php?type=wall"><strong>Все модели</strong></a></li>
  <?php
 $result = mysql_query("SELECT * FROM category WHERE type ='wall'");
 if(mysql_num_rows($result)>0)
 {
	 do
 {
	 echo'
	 <li><a href="view_cat.php?cat='.strtolower($row["brand"]).'&type='.$row["type"].'">'.$row["brand"].'</a></li>
	 ';
	 
 }
 while ($row = mysql_fetch_array($result));
 }
 ?>
 </ul>
</li>

</ul>
</div>