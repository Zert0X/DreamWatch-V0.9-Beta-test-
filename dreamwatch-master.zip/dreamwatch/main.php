<!DOCTYPE html>
<html>
<head>
<link rel="shortcut icon" href="/images/favicon.png" type="image/png">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <link  rel="stylesheet" href="css/style.css" />
    <link  rel="stylesheet" href="css/reset.css" />
</head>
<body>
<div id="block-body" >
<?php
include("include/block-header.php")
?>
<div id="block-right">
</div>
<div id="block-content">
</div>
<?php
include("include/block-footer.php")
?>
</div>
</body>
</html>